//Bryan Coleman
//COP4530
//10/4/2019
//Prof. Bob Myers

template<typename T>
List<T>::const_iterator::const_iterator():current{nullptr}
{
}

template<typename T>
const T& List<T>::const_iterator::operator*() const
{
	return retrieve();
}

template<typename T>
typename List<T>::const_iterator& List<T>::const_iterator::operator++()
{
	current = current->next;
	return *this;
}

template<typename T>
typename List<T>::const_iterator List<T>::const_iterator::operator++(int)
{
	const_iterator copy = *this;
	++(*this);
	return copy;
}

template<typename T>
typename List<T>::const_iterator& List<T>::const_iterator::operator--()
{
	current = current->prev;
	return *this;
}

template<typename T>
typename List<T>::const_iterator List<T>::const_iterator::operator--(int)
{
	const_iterator copy = *this;
	--(*this);
	return copy;
}

template<typename T>
bool List<T>::const_iterator::operator==(const typename List<T>::const_iterator& rhs) const
{
	return (current == rhs.current);
}

template<typename T>
bool List<T>::const_iterator::operator!=(const typename List<T>::const_iterator& rhs) const
{
	return !(*this == rhs);
}

template<typename T>
T& List<T>::const_iterator::retrieve() const
{
	return current->data;
}

template<typename T>
List<T>::const_iterator::const_iterator(typename List<T>::Node *p):current{p}
{
}

template<typename T>
List<T>::iterator::iterator()
{
}

template<typename T>
T& List<T>::iterator::operator*()
{
	return const_iterator::retrieve();
}

template<typename T>
const T& List<T>::iterator::operator*() const
{
	return const_iterator::operator*();
}

template<typename T>
typename List<T>::iterator& List<T>::iterator::operator++()
{
	this->current = this->current->next;
	return *this;
}

template<typename T>
typename List<T>::iterator List<T>::iterator::operator++(int)
{
	iterator copy = *this;
	++(*this);
	return copy;
}

template<typename T>
typename List<T>::iterator& List<T>::iterator::operator--()
{
        this->current = this->current->prev;
        return *this;
}

template<typename T>
typename List<T>::iterator List<T>::iterator::operator--(int)
{
        iterator copy = *this;
        --(*this);
        return copy;
}

template<typename T>
List<T>::iterator::iterator(typename List<T>::Node *p):const_iterator{p}
{
}

template<typename T>
List<T>::List()
{
	init();
}

template<typename T>
List<T>::List(const List& rhs)
{
	init();
	for(auto & x: rhs)
		push_back(x);
}

template<typename T>
List<T>::List(List && rhs):
head{rhs.head}, tail{rhs.tail}, theSize{rhs.theSize}
{
	rhs.head = nullptr;
	rhs.tail = nullptr;
	rhs.theSize = 0;
}

template<typename T>
List<T>::List(int num, const T& val)
{
	init();
	for(int i = 0; i < num; i++)
		push_back(val);
}

template<typename T>
List<T>::List(typename List<T>::const_iterator start, typename List<T>::const_iterator end)
{
	init();
	for(auto temp = start; temp != end; temp++)
		push_back(*temp);
}

template<typename T>
List<T>::List(std::initializer_list<T> iList)
{
	init();
	for(auto & x: iList)
		push_back(x);
}

template<typename T>
List<T>::~List()
{
	clear();
	delete head;
	delete tail;
}

template<typename T>
const List<T>& List<T>::operator=(const List& rhs)
{
	List copy = rhs;
	std::swap(*this,copy);
	return *this;
}

template<typename T>
List<T>& List<T>::operator=(List && rhs)
{
	std::swap(theSize, rhs.theSize);
	std::swap(head, rhs.head);
	std::swap(tail, rhs.tail);
}

template<typename T>
List<T>& List<T>::operator=(std::initializer_list<T> iList)
{
	List copy(iList);
	std::swap(*this, copy);
	return *this;
}	

template<typename T>
int List<T>::size() const
{
	return theSize;
}

template<typename T>
bool List<T>::empty() const
{
	return (size() == 0);
}

template<typename T>
void List<T>::clear()
{
	while(!empty())
		pop_front();
}

template<typename T>
void List<T>::reverse()
{
	if(size() == 0)
		return;
	for(auto ptr = begin(); ptr != end(); ptr--)
	{
		auto temp = ptr.current;
		std::swap(temp->next,temp->prev);
	}
	auto ptr = end();
	auto temp = ptr.current;
	std::swap(temp->next,temp->prev);
	std::swap(head,tail);
}

template<typename T>
T& List<T>::front()
{
	return *begin();
}

template<typename T>
const T& List<T>::front() const
{
	return *begin();
}

template<typename T>
T& List<T>::back()
{
	return *--end();
}

template<typename T>
const T& List<T>::back() const
{
	return *--end();
}

template<typename T>
void List<T>::push_front(const T & val)
{
	insert(begin(), val);
}

template<typename T>
void List<T>::push_front(T && val)
{
	insert(begin(), std::move(val));
}

template<typename T>
void List<T>::push_back(const T & val)
{
	insert(end(), val);
}

template<typename T>
void List<T>::push_back(T && val)
{
	insert(end(), std::move(val));
}

template<typename T>
void List<T>::pop_front()
{
	erase(begin());
}

template<typename T>
void List<T>::pop_back()
{
	erase(--end());
}

template<typename T>
void List<T>::remove(const T & val)
{
	for(auto ptr = begin(); ptr != end(); ptr++)
	{
		if(*ptr == val)
			erase(ptr);
	}
}

template<typename T>
template<typename PREDICATE>
void List<T>::remove_if(PREDICATE pred)
{
	for(auto ptr = begin(); ptr != end(); ptr++)
	{
		if(pred(*ptr) == true)
			erase(ptr);
	}
}

template<typename T>
void List<T>::print(std::ostream & os, char ofc) const
{
	for(auto ptr = begin(); ptr != end(); ptr++)
		os << *ptr << ofc;
}

template<typename T>
typename List<T>::iterator List<T>::begin()
{
	return iterator(head->next);
}

template<typename T>
typename List<T>::const_iterator List<T>::begin() const
{
	return const_iterator(head->next);
}

template<typename T>
typename List<T>::iterator List<T>::end()
{
	return iterator(tail);
}

template<typename T>
typename List<T>::const_iterator List<T>::end() const
{
	return const_iterator(tail);
}

template<typename T>
typename List<T>::iterator List<T>::insert(typename List<T>::iterator itr, const T & val)
{
	auto * temp = itr.current;
	++theSize;
	return iterator(temp->prev = temp->prev->next = new Node{val, temp->prev, temp});
}

template<typename T>
typename List<T>::iterator List<T>::insert(typename List<T>::iterator itr, T && val)
{
	auto * temp = itr.current;
        ++theSize;
        return iterator(temp->prev = temp->prev->next = new Node{std::move(val), temp->prev, temp});
}

template<typename T>
typename List<T>::iterator List<T>::erase(typename List<T>::iterator itr)
{
	auto * temp = itr.current;
	iterator returnVal(temp->next);
	temp->prev->next = temp->next;
	temp->next->prev = temp->prev;
	delete temp;
	--theSize;
	return returnVal;
}

template<typename T>
typename List<T>::iterator List<T>::erase(typename List<T>::iterator start,typename List<T>::iterator end)
{
	for(iterator ptr = start; ptr != end;)
		ptr = erase(ptr);
}

template<typename T>
void List<T>::init()
{
	theSize = 0;
	head = new Node;
	tail = new Node;
	head->next = tail;
	tail->prev = head;
}

template<typename T>
bool operator==(const List<T> & lhs, const List<T> & rhs)
{
	if(lhs.size() == rhs.size())
	{
		auto lhsPtr = lhs.begin();
		auto rhsPtr = rhs.begin();
		while(lhsPtr != lhs.end())
		{
			if(*lhsPtr != *rhsPtr)
				return false;
			lhsPtr++;
		}
		return true;
	}
	return false;
}

template<typename T>
bool operator!=(const List<T> & lhs, const List<T> & rhs)
{
	return !(lhs == rhs);
}

template<typename T>
std::ostream & operator<<(std::ostream & os, const List<T> &l)
{
	l.print(os);
	return os;
}




















