
//TList class

//default constructor; empty list
template <typename T>
TList<T>::TList()
{
	size = 0;
	first = new Node<T>(0);
	last = new Node<T>(0);
}

//constructor; with values
template <typename T>
TList<T>::TList(T val, int num)
{
	size = 0;
        first = new Node<T>(0);
        last = new Node<T>(0);

	for(int i = 0; i < num; i++)
		InsertBack(val);
}

//destructor
template <typename T>
TList<T>::~TList()
{
	Clear();
}

//copy constructor
template <typename T>
TList<T>::TList(const TList & L)
{
	size = 0;
        first = new Node<T>(0);
        last = new Node<T>(0);

	auto * temp = L.GetIterator().ptr;
	for(int i = 0; i < L.GetSize(); i++)
	{
		InsertBack(temp->data);
		temp = temp->next;
	}

}

//copy assignment operator
template <typename T>
TList<T> & TList<T>::operator=(const TList & L)
{
	TList copy = L;
	std::swap(*this, copy);
	return *this;
}

//move constructor
template <typename T>
TList<T>::TList(TList && L)
:size{L.size}, first{L.first}, last{L.last}
{
	L.size = 0;
	L.first = nullptr;
	L.last = nullptr;
}

//move assignment operator
template <typename T>
TList<T> & TList<T>::operator=(TList && L)
{
	std::swap(size, L.size);
	std::swap(first, L.first);
	std::swap(last, L.last);
	return *this;
}

//checks to see whether list is empty or not
template <typename T>
bool TList<T>::IsEmpty() const
{
	return (GetSize() == 0);
}

//reset the list to be empty
template <typename T>
void TList<T>::Clear()
{
	int temp = size;
	for(int i = 0; i < temp; i++)
		RemoveBack();
}

//returns the size of the list
template <typename T>
int TList<T>::GetSize() const
{
	return size;
}

//insert at the begining of list
template <typename T>
void TList<T>::InsertFront(const T & d)
{
	if(size == 0)
	{
		first = new Node<T>(d);
		size++;
	}
	else if(size == 1)
	{
		auto * temp = new Node<T>(d);
		last = first;
		first = temp;
		first->next = last;
		last->prev = first;
		size++;
	}
	else
		Insert(GetIterator(), d);
}

//insert at the end of list
template <typename T>
void TList<T>::InsertBack(const T & d)
{
	if(size == 0)
                first = new Node<T>(d);
        else if(size == 1)
        {
                last = new Node<T>(d);
                first->next = last;
                last->prev = first;	
	}
	else
	{
		auto * incoming = new Node<T>(d);
		auto * temp = GetIteratorEnd().ptr;
		temp->next = incoming;
		incoming->prev = temp;
		last = incoming;
	}
	size++;
}

//remove first element of list
template <typename T>
void TList<T>::RemoveFront()
{
	if(size == 0);
	else if(size == 2)
	{
		auto * temp = last;
		delete last;
		last = new Node<T>(0);
		first = temp;
		size--;
	}	
	else if(size == 1)
	{
		delete first;
		first = new Node<T>(0);
		size--;
	}
	else
	{
		auto * temp = GetIterator().ptr;
		auto * temptwo = temp->next;
		temp->next->prev = nullptr;
		first = temptwo;
		delete temp;
		size--;
	}
}

//remove last element of list
template <typename T>
void TList<T>::RemoveBack()
{
	if(size == 0);
	else if(size == 2)
	{
		first->next = nullptr;
		delete last;
		last = new Node<T>(0);
		size--;
	}
	else if(size == 1)
	{
		delete first;
		first = new Node<T>(0);
		size--;
	}	
	else
	{
		auto *temp = GetIteratorEnd().ptr;
		auto *temptwo = temp->prev;
		temp->prev->next = nullptr;
		last = temptwo;
		delete temp;
		size--;
	}
}

//return first elemEnt of the list
template <typename T>
T& TList<T>::GetFirst() const
{
	if(!IsEmpty())
		return first->data;
	return dummy;
}

//return last element of the list
template <typename T>
T& TList<T>::GetLast() const
{
	if(!IsEmpty())
		return last->data;
	return dummy;
}

//return iterator to the first value
template <typename T>
TListIterator<T> TList<T>::GetIterator() const
{
	TListIterator<T> temp;
	temp.ptr = first;
	return temp;
}

//return iterator to the last value
template <typename T>
TListIterator<T> TList<T>::GetIteratorEnd() const
{
	TListIterator<T> temp;
	temp.ptr = last;
	return temp;
}

//insert data before the iterator position
template <typename T>
void TList<T>::Insert(TListIterator<T> pos, const T & d)
{
	if(size == 0)
		first = new Node<T>(d);
	else if(size == 1)
	{
		last = new Node<T>(d);
		auto temp = last;
		last = first;
		first = temp;
	}
	else
	{
		auto * temp = pos.ptr;
		auto * incoming = new Node<T>(d);
		if(temp->prev == nullptr)
		{
			temp->prev = incoming;
			incoming->prev = nullptr;
			incoming->next = temp;
			first = incoming;
		}
		else
		{
			incoming->next = temp;
			incoming->prev = temp->prev;
			temp->prev->next = incoming;
			temp->prev = temp->prev->next;
		}
	}
	size++;
}

//remove data at the iterator and move iterator to next postition
template <typename T>
TListIterator<T> TList<T>::Remove(TListIterator<T> pos)
{
	auto * temp = pos.ptr;
	if(size == 0)
	{
		TListIterator<T> itr;
		itr.ptr = first;
		return itr;
	}
	if(size == 1)
	{
		TListIterator<T> itr;
		Clear();
		itr.ptr = first;
		return itr;
	}
	if(temp->prev == nullptr)
	{
		auto * temp = first->next;
		TListIterator<T> temptwo;
		temptwo.ptr = temp->next;
		temp->prev = nullptr;
		delete first;
		first = temp;
		size--;
		return temptwo;
	}
	else if(temp->next == nullptr)
	{
		auto * temp = last->prev;
		TListIterator<T> temptwo;
		temptwo.ptr = temp->prev;
		temp->next = nullptr;
		delete last;
		last = temp;
		size--;
		return temptwo;
	}
	else
	{
		temp->prev->next = temp->next;
		temp->next->prev = temp->prev;
		TListIterator<T> temptwo;
		temptwo.ptr = temp->next;
		size--;
		delete temp;
		return temptwo;
	}
}

//print list in order, seperator by ' '
template <typename T>
void TList<T>::Print(std::ostream & os, char deli) const
{

	auto * temp = first;
	
	while(temp != nullptr && size > 0)
	{
		os << temp->data << deli;
		temp = temp->next;
	}

}

//TListIterator class

//default constructor
template <typename T>
TListIterator<T>::TListIterator() : ptr{nullptr}
{
}

//does the current element have a next element?
template <typename T>
bool TListIterator<T>::HasNext() const
{
	auto *temp = ptr->next;
	if(temp == nullptr)
		return false;
	return true;
}

//does the current element have a previous element?
template <typename T>
bool TListIterator<T>::HasPrevious() const
{
	auto *temp = ptr->prev;
	if(temp == nullptr)
		return false;
	return true;
}

//advance to the next item in the list
template <typename T>
TListIterator<T> TListIterator<T>::Next()
{
	if(ptr->next != nullptr)
		ptr = ptr->next;
	TListIterator<T> temp;
	temp.ptr = ptr;
	return temp;
}

//retreat to the previous item in the list
template <typename T>
TListIterator<T> TListIterator<T>::Previous()
{
	if(ptr->prev != nullptr)
		ptr = ptr->prev;
	TListIterator<T> temp;
	temp.ptr = ptr;
	return temp;
}

//return data of current node
template <typename T>
T & TListIterator<T>::GetData() const
{
	return ptr->data;
}

template <typename T>
TList<T> operator+(const TList<T>& listOne, const TList<T>& listTwo)
{
	TList<T> ans;
	ans = listOne;
	TListIterator<T> temp = listTwo.GetIterator();
	for(int i = 0; i < listTwo.GetSize(); i++)
	{
		ans.InsertBack(temp.GetData());
		temp.Next();
	}

	return ans;
}



