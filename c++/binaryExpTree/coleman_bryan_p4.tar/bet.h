#ifndef BET_H
#define BET_H
#include<string>
#include<sstream>
#include<vector>
using namespace std;
class BET
{
	public:
	struct BinaryNode
        {
                std::string data;
                BinaryNode *left;
                BinaryNode *right;
                BinaryNode(const std::string & d = string{}, BinaryNode *l = nullptr,
                        BinaryNode *r = nullptr) : data{d}, left{l}, right{r} {}
                BinaryNode(std::string && d, BinaryNode *l = nullptr,
                        BinaryNode *r = nullptr) : data{move(d)}, left{l}, right{r} {}
        };

	BET();
	BET(const string & postfix);
	BET(const BET &);
	~BET();
	bool buildFromPostfix(const string & postfix);
	const BET & operator=(const BET &);

	void printInfixExpression();
	void printPostfixExpression() const;
	size_t size() const;
	size_t leaf_nodes() const;
	bool empty() const;
	
	private:
	
	void printInfixExpression(BinaryNode *n);
	void makeEmpty(BinaryNode * & t);
	BinaryNode * clone(BinaryNode *t) const;
	void printPostfixExpression(BinaryNode *n) const;
	size_t size(BinaryNode *t) const;
	size_t leaf_nodes(BinaryNode *t) const;

	int prec(string x) const;
	bool checkOperator(string x) const;

	BinaryNode *root;
	vector<BinaryNode*> betv;
};

#include "bet.hpp"	

#endif
