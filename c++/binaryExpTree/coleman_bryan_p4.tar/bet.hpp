//public functions

//default constructor
BET::BET()
{
	root = nullptr;
}

//one-parameter consuctor, postfix is string, tokens seperated by spaces
BET::BET(const string & postfix)
{
	root = nullptr;
	buildFromPostfix(postfix);
}

//copy constructor, deep copy
BET::BET(const BET & x)
{
	root = nullptr;
	root = clone(x.root);
}

//destructor
BET::~BET()
{
	makeEmpty(root);
	delete root;
}

//takes a postfix expression, if the tree contains nodes - delete existing
//return false if error occurs
bool BET::buildFromPostfix(const string & postfix)
{
	string token;
	if(!empty())
		makeEmpty(root);
	istringstream ss(postfix);
	while(getline(ss,token,' '))
	{
		if(!checkOperator(token))
		{
			BinaryNode *temp = new BinaryNode(token,nullptr,nullptr);
			betv.push_back(temp);
		}
		else
		{
			BinaryNode *lhs, *rhs;
			if(betv.empty())
			{
				cout<<"stack empty error"<<endl;
				return false;
			}
			rhs = betv.back();
			betv.pop_back();
			if(betv.empty())
			{
				cout<<"stack empty error"<<endl;
				return false;
			}
			lhs = betv.back();
			betv.pop_back();
			BinaryNode *temp2 = new BinaryNode(token,lhs,rhs);
			betv.push_back(temp2);
		}
	}
	if(betv.empty())
	{
		cout<<"stack empty error"<<endl;
		return false;
	}
	root = betv.back();
	betv.pop_back();
	return true;
}

//assignment operator, deep copy
const BET & BET::operator=(const BET & x)
{
	makeEmpty(root);
	root = clone(x.root);
	return *this;
}

//print out infix form expression, use private recursive version
void BET::printInfixExpression()
{
	printInfixExpression(root);
}

//print out postfix form expression, use private recursive version
void BET::printPostfixExpression() const
{
	printPostfixExpression(root);
}

//return the number of nodes, use private recursive function
size_t BET::size() const
{
	return size(root);
}

//return thenumber of leaf node, use private recursive function
size_t BET::leaf_nodes() const
{
	return leaf_nodes(root);
}

//return true if tree is empty
bool BET::empty() const
{
	return(root == nullptr);
}

//private functions

//print print to the proper infixexpression, add parentheses as needed
void BET::printInfixExpression(BinaryNode * n) 
{
	if(n != nullptr)
	{
		bool flag = false;
		if(n->left != nullptr)
		{
			if((checkOperator(n->data) && checkOperator(n->left->data))
				&& (prec(n->data) >=  prec(n->left->data)))
			{
				if(n != root || (prec(n->data) > prec(n->left->data)))
				{
					cout<<"( ";
					flag = true;
				}
			}
			printInfixExpression(n->left);
			if(flag)
				cout<<") ";
		}	cout<<n->data<< " ";
		
		flag = false;
		if(n->right != nullptr)
		{
			if((checkOperator(n->data) && checkOperator(n->right->data))
                        	&& (prec(n->data) >= prec(n->right->data)))
                	{
				cout<<"( ";
                        	flag = true;
                	}
                	printInfixExpression(n->right);
                	if(flag)
                        	cout<<") ";
		}
	}
	if(n == root)
		cout<<endl;
}

//delete all nodes in the subtree pointed to by t
void BET::makeEmpty(BinaryNode * & t)
{
	if(t != nullptr)
	{
		makeEmpty(t->left);
		makeEmpty(t->right);
		delete t;
	}
	t = nullptr;
}

//clone all nodes in the subtree pointed to by t, make use of assignment operator
BET::BinaryNode * BET::clone(BinaryNode * t) const
{
	if(t == nullptr)
		return nullptr;
	else
		return new BinaryNode{t->data, clone(t->left), clone(t->right)};
}

//print in postfix
void BET::printPostfixExpression(BinaryNode *n) const
{
	if(n != nullptr)
	{
		printPostfixExpression(n->left);
		printPostfixExpression(n->right);
		if(n != root)
			cout<<n->data<< " ";
		else
			cout<<n->data<<endl;
	}
}

//return the number of nodes in the subtree
size_t BET::size(BinaryNode *t) const
{
	int s = 0;
	if(t == nullptr)
		return s;
	s++;
	s += size(t->left);
	s += size(t->right);
	return s;
}

//return number of leaf nodes
size_t BET::leaf_nodes(BinaryNode *t) const
{
	int s = 0;
	if(t == nullptr)
		return 0;
	if(t->left == nullptr && t->right == nullptr)
		return 1;
	s += leaf_nodes(t->left);
	s += leaf_nodes(t->right);
	return s;
}

//return precedence
int BET::prec(string x) const
{
        if(x == "*" || x == "/") return 2;
        if(x == "+" || x == "-") return 1;
        return 0;
}

//check if operator
bool BET::checkOperator(string x) const
{
	if(x == "+" ||
        x == "-" ||
        x == "*" ||
        x == "/")
                return true;
        return false;
}














