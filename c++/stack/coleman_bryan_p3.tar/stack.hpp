
//bryan coleman
//cop4530
//Bob Myers
//10.18.19

//can be empty because were using vector adapter class, which dynamically allocates
template<typename T>
Stack<T>::Stack()
{
}

//destructor
template<typename T>
Stack<T>::~Stack()
{
	v.clear();
}

//copy constructor, vector = x(stack)'s vector
template<typename T>
Stack<T>::Stack(const Stack<T> & x)
{
	v = x.v;
}

//move constructor
template<typename T>
Stack<T>::Stack(Stack<T> && x)
{
	v = x.v;
	x.v = std::vector<T>();
}

//copy assignment =
template<typename T>
Stack<T> & Stack<T>::operator=(const Stack<T> & x)
{
	auto copy = x;
	std::swap(*this, copy);
	return *this;
}

//move assignment =
template<typename T>
Stack<T> & Stack<T>::operator=(Stack<T> && x)
{
	std::swap(v, x.v);
	return *this;
}

//return true if stack is empty
template<typename T>
bool Stack<T>::empty() const
{
	return v.empty();
}

//clear the stack out
template<typename T>
void Stack<T>::clear()
{
	v.clear();
}

//push to the top of the stack
template<typename T>
void Stack<T>::push(const T& x)
{
	v.push_back(x);
}

//function to push for r value
template<typename T>
void Stack<T>::push(T && x)
{
	v.push_back(x);
}

//delete top element
template<typename T> 
void Stack<T>::pop()
{
	v.pop_back();
}

//return value of top, able to be manipulated
template<typename T>
T& Stack<T>::top()
{
	return v.back();
}

//return value of top
template<typename T>
const T& Stack<T>::top() const
{
	return v.back();
}

//return size
template<typename T>
int Stack<T>::size() const
{
	return v.size();
}

//print out the stack from bottom to top, last element does not print the ofc
template<typename T>
void Stack<T>::print(std::ostream & os, char ofc) const
{
	int i = 0;
	for(auto itr = v.begin(); itr != v.end(); itr++)
	{
		if(i == v.size() - 1)
			os<<*itr;
		else
			os << *itr << ofc;
		i++;
	}
}

//super simple << overload
template<typename T>
std::ostream & operator<<(std::ostream & os, const Stack<T> & x)
{
	x.print(os);
	return os;
}

//overload operator==
template<typename T>
bool operator==(const Stack<T> & x, const Stack<T> & y)
{
	if(x.size() != y.size())	//different sizes
		return false;
	auto temp = x;			//making temp stacks
	auto temp2 = y;
	while(!temp.empty())
	{
		if(temp.top() != temp2.top())	//if any value is different return false
			return false;
		temp.pop();
		temp2.pop();
	}
	return true;	
}

//overload operator!=
template<typename T>
bool operator!=(const Stack<T> & x, const Stack<T> & y)
{
	return !(x == y);
}

//overload operator<=
template<typename T>
bool operator<=(const Stack<T> & x, const Stack<T> & y)
{
	if(x == y)
		return true;		//if equal return true;end of sentence;
	if(x.size() > y.size())		//if x has a greater size return false 
		return false;		//since we need to get to the first values end
	auto temp = x;
	auto temp2 = y;;
	while(!temp.empty())
	{
		if(temp.top() > temp2.top())
			return false;
		temp.pop();
		temp2.pop();
	}
	return true;
}



















