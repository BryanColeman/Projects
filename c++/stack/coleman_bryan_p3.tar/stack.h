#ifndef DL_STACK_H
#define DL_STACK_H
#include<iostream>
#include<vector>
#include<utility>

namespace cop4530{
template<typename T>
class Stack
{
	public:
	Stack();
	~Stack();
	Stack(const Stack<T> & x);
	Stack(Stack<T> && x);
	Stack<T>& operator=(const Stack<T> & x);
	Stack<T>& operator=(Stack<T> && x);

	bool empty() const;
	void clear();
	void push(const T& x);
	void push(T && x);
	void pop();
	T& top();
	const T& top() const;
	int size() const;
	void print(std::ostream& os, char ofc = ' ') const;
	
	private:
	std::vector<T> v;
	
};

template<typename T>
	bool operator==(const Stack<T> & x, const Stack<T> & y);

template<typename T>
	bool operator!=(const Stack<T> & x, const Stack<T> & y);

template<typename T>
	std::ostream & operator<<(std::ostream & os, const Stack<T> & x);

template<typename T>
	bool operator<=(const Stack<T> & x, const Stack<T> & y);

#include "stack.hpp"

}

#endif
















